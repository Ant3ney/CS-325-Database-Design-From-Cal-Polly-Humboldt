-- Lab 9: Sergio Monterroso and Anthony Cavuoti 10/21/2022

start set-up-ex-tbls.sql

spool lab9-out.txt

prompt Sergio Monterroso and Anthony Cavuoti

prompt
prompt Query 1:
select *
from dept
order by dept_loc;

prompt
prompt Query 2:
select *
from dept
order by dept_name;

prompt
prompt Query 3:
select empl_last_name, dept_name, salary, hiredate
from empl, dept
where empl.dept_num = dept.dept_num
order by dept_name, hiredate;

prompt
prompt Query 4:
select empl_last_name, dept_name, salary, hiredate
from empl, dept
where empl.dept_num = dept.dept_num
order by salary desc, hiredate;

prompt
prompt Query 5:
select mgr, min(hiredate)
from empl
group by mgr;

prompt
prompt Query 6:
select mgr, min(hiredate)
from empl
group by mgr
having min(hiredate) > '01-Jan-2015';


prompt
prompt Query 7:
select dept_name, count(empl_num)
from dept, empl
where empl.dept_num = dept.dept_num
group by dept_name
order by count(empl_num);

prompt
prompt Query 8:
select dept_name, count(empl_num)
from dept, empl
where empl.dept_num = dept.dept_num
group by dept_name
having avg(salary) < 2000
order by count(empl_num);

prompt
prompt Query 9:
select empl_last_name, job_title, commission
from empl
order by commission;


spool off
